
import { GoogleGenAI } from "@google/genai";
import { SYSTEM_PROMPT, KNOWLEDGE_BASE } from "../constants";

// The platform injects GEMINI_API_KEY into process.env
// Always use gemini-3-flash-preview for general text tasks and free mode compatibility
let genAI: GoogleGenAI | null = null;

function getGenAI() {
    if (!genAI) {
        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey) {
            throw new Error("GEMINI_API_KEY is not defined in the environment.");
        }
        genAI = new GoogleGenAI({ apiKey });
    }
    return genAI;
}

export const chatWithAssistant = async (history: { role: 'user' | 'model', parts: { text: string }[] }[], message: string) => {
    try {
        const ai = getGenAI();
        const response = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: [
                ...history,
                {
                    role: 'user',
                    parts: [{ text: message }]
                }
            ],
            config: {
                systemInstruction: `${SYSTEM_PROMPT}\n\nKNOWLEDGE BASE INTEGRATED:\n${KNOWLEDGE_BASE}`
            }
        });

        // Use response.text property directly as per skill recommendation
        return response.text || "La información específica solicitada no se encuentra detallada en la Guía Operativa o los Protocolos de Actuación vigentes.";
    } catch (error) {
        console.error("Gemini API Error details:", error);
        throw error;
    }
};
